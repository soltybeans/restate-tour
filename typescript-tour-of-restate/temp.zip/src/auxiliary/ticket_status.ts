export enum TicketStatus {
    Available,
    Reserved,
    Sold,
}